The enclosed MIB is to be used to support the Storage Array Origin
SNMP TRAP and GET requests.  For proper operation, only the description
fields of this file can be modified. Any other changes may result in
the customers SNMP Manager improperly decoding TRAPs and can cause
SNMP GET requests sent to the Storage Array to fail.

The enclosed MIB will co-exist with the SM10-R3-MIB that is used
in SNMP Managers for configurations with Event Monitor SNMP support.

